#!/bin/sh

python hello.py
